// src/components/WhatsAppFollowUpList.tsx
import React, { useState } from 'react';
import { FollowUpItem, buildWhatsAppDirectLink } from '../lib/whatsappCadence';

interface Props {
  items: FollowUpItem[];
}

export const WhatsAppFollowUpList: React.FC<Props> = ({ items }) => {
  const [filterStage, setFilterStage] = useState<string>('ALL');

  const filtered = items.filter((item) => {
    if (filterStage === 'ALL') return true;
    return item.stage === filterStage;
  });

  return (
    <div className="bg-white rounded-xl shadow border border-gray-100 p-5">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between pb-4 border-b border-gray-100 gap-3">
        <div>
          <h2 className="text-lg font-bold text-gray-900">Customer Follow-up Cadence (WhatsApp)</h2>
          <p className="text-xs text-gray-500">Assisted zero-cost cadence prompts with 1-tap WhatsApp messaging</p>
        </div>
        <div className="flex items-center gap-2">
          <label className="text-xs font-semibold text-gray-500 uppercase">Stage:</label>
          <select 
            value={filterStage} 
            onChange={(e) => setFilterStage(e.target.value)}
            className="text-xs border border-gray-300 rounded px-2 py-1 bg-white"
          >
            <option value="ALL">All Active</option>
            <option value="DAY_3">Day 3 (Wear Check)</option>
            <option value="DAY_14">Day 14 (Layering)</option>
            <option value="DAY_60">Day 60 (Refill Check)</option>
            <option value="DAY_90">Day 90 (Re-engagement)</option>
            <option value="DAY_120">Day 120 (Win-back)</option>
          </select>
        </div>
      </div>

      <div className="mt-4 overflow-x-auto">
        <table className="w-full text-left text-sm">
          <thead>
            <tr className="border-b border-gray-200 text-xs font-semibold text-gray-500 uppercase">
              <th className="py-2 px-3">Customer</th>
              <th className="py-2 px-3">Blend / Fragrance</th>
              <th className="py-2 px-3">Cadence Stage</th>
              <th className="py-2 px-3">Purchased On</th>
              <th className="py-2 px-3 text-right">Action</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-gray-100">
            {filtered.length === 0 ? (
              <tr>
                <td colSpan={5} className="py-6 text-center text-gray-400">
                  No pending customer follow-ups for this stage.
                </td>
              </tr>
            ) : (
              filtered.map((item) => (
                <tr key={item.id} className="hover:bg-gray-50 transition">
                  <td className="py-3 px-3 font-medium text-gray-900">
                    <div>{item.customerName}</div>
                    <div className="text-xs text-gray-400">+{item.phone}</div>
                  </td>
                  <td className="py-3 px-3 text-gray-700">{item.fragranceName}</td>
                  <td className="py-3 px-3">
                    <span className={`inline-flex px-2 py-1 rounded text-xs font-semibold ${
                      item.stage === 'DAY_3' ? 'bg-blue-100 text-blue-800' :
                      item.stage === 'DAY_14' ? 'bg-purple-100 text-purple-800' :
                      item.stage === 'DAY_60' ? 'bg-amber-100 text-amber-800' :
                      'bg-emerald-100 text-emerald-800'
                    }`}>
                      {item.stage.replace('_', ' ')}
                    </span>
                  </td>
                  <td className="py-3 px-3 text-gray-500 text-xs">
                    {new Date(item.purchaseDate).toLocaleDateString('en-IN', { day: 'numeric', month: 'short', year: 'numeric' })}
                  </td>
                  <td className="py-3 px-3 text-right">
                    <a
                      href={buildWhatsAppDirectLink(item)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white rounded text-xs font-medium transition shadow-sm"
                    >
                      <span>💬</span> Send WhatsApp
                    </a>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};
