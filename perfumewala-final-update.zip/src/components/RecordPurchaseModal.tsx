// src/components/RecordPurchaseModal.tsx
import React, { useState } from 'react';

interface RecordPurchaseModalProps {
  isOpen: boolean;
  onClose: () => void;
  customerId: string;
  customerName: string;
  customerPhone: string;
  outlets?: { id: string; name: string }[];
  onSuccess?: () => void;
  supabaseClient?: any;
}

export const RecordPurchaseModal: React.FC<RecordPurchaseModalProps> = ({
  isOpen,
  onClose,
  customerId,
  customerName,
  customerPhone,
  outlets = [],
  onSuccess,
  supabaseClient,
}) => {
  const [productName, setProductName] = useState('');
  const [totalAmount, setTotalAmount] = useState<number | ''>('');
  const [paymentMethod, setPaymentMethod] = useState<'CASH' | 'UPI' | 'CREDIT_CARD' | 'DEBIT_CARD' | 'SPLIT'>('UPI');
  const [cashSplit, setCashSplit] = useState<number | ''>('');
  const [upiSplit, setUpiSplit] = useState<number | ''>('');
  const [selectedOutlet, setSelectedOutlet] = useState(outlets[0]?.id || '');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState('');

  if (!isOpen) return null;

  const numAmount = Number(totalAmount) || 0;
  // 18% GST calculation (included in retail gross total)
  const gstAmount = Math.round((numAmount * 18 / 118) * 100) / 100;
  const subtotalAmount = Math.round((numAmount - gstAmount) * 100) / 100;

  const printThermalReceipt = (invNo: string) => {
    const printWindow = window.open('', '_blank', 'width=350,height=500');
    if (!printWindow) return;
    printWindow.document.write(`
      <html>
        <head>
          <title>PerfumeWala Receipt - ${invNo}</title>
          <style>
            body { font-family: monospace; font-size: 12px; width: 280px; margin: 0 auto; padding: 10px; }
            .center { text-align: center; }
            .bold { font-weight: bold; }
            .line { border-top: 1px dashed #000; margin: 8px 0; }
            .row { display: flex; justify-content: space-between; }
          </style>
        </head>
        <body>
          <div class="center bold">PERFUMEWALA</div>
          <div class="center">Artisan Perfume Experience Bar</div>
          <div class="center">GSTIN: 07AAACP1234F1Z8</div>
          <div class="line"></div>
          <div>Invoice: ${invNo}</div>
          <div>Date: ${new Date().toLocaleDateString('en-IN')}</div>
          <div>Customer: ${customerName}</div>
          <div>Phone: +${customerPhone}</div>
          <div class="line"></div>
          <div class="row"><span class="bold">Item</span><span class="bold">Amount</span></div>
          <div class="row"><span>${productName}</span><span>₹${numAmount.toFixed(2)}</span></div>
          <div class="line"></div>
          <div class="row"><span>Taxable Value:</span><span>₹${subtotalAmount.toFixed(2)}</span></div>
          <div class="row"><span>GST (18% Incl.):</span><span>₹${gstAmount.toFixed(2)}</span></div>
          <div class="row bold"><span>Grand Total:</span><span>₹${numAmount.toFixed(2)}</span></div>
          <div class="row"><span>Payment Mode:</span><span>${paymentMethod}</span></div>
          <div class="line"></div>
          <div class="center">Thank you for visiting!</div>
          <div class="center">Maceration advice: Store in cool, dark place for 7 days.</div>
        </body>
      </html>
    `);
    printWindow.document.close();
    printWindow.focus();
    printWindow.print();
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (numAmount <= 0) {
      setErrorMsg('Please enter a valid sale amount.');
      return;
    }

    if (paymentMethod === 'SPLIT') {
      const c = Number(cashSplit) || 0;
      const u = Number(upiSplit) || 0;
      if (Math.abs((c + u) - numAmount) > 0.01) {
        setErrorMsg(`Split sum (Cash ₹${c} + UPI ₹${u} = ₹${c + u}) does not match Total Amount (₹${numAmount}).`);
        return;
      }
    }

    setLoading(true);
    setErrorMsg('');

    try {
      if (!supabaseClient) throw new Error('Supabase client not initialized');

      const payload: any = {
        customer_id: customerId,
        product_name: productName,
        total_amount: numAmount,
        subtotal_amount: subtotalAmount,
        gst_amount: gstAmount,
        gst_rate_pct: 18.0,
        payment_method: paymentMethod,
        payment_status: 'PAID',
        payment_split_cash: paymentMethod === 'SPLIT' ? Number(cashSplit) || 0 : (paymentMethod === 'CASH' ? numAmount : 0),
        payment_split_upi: paymentMethod === 'SPLIT' ? Number(upiSplit) || 0 : (paymentMethod === 'UPI' ? numAmount : 0),
      };

      if (selectedOutlet) {
        payload.outlet_id = selectedOutlet;
      }

      const { data, error } = await supabaseClient.from('purchases').insert([payload]).select();

      if (error) throw error;

      const generatedInvoice = data?.[0]?.invoice_number || 'PW-RECEIPT';
      printThermalReceipt(generatedInvoice);

      if (onSuccess) onSuccess();
      onClose();
    } catch (err: any) {
      setErrorMsg(err?.message || 'Failed to record purchase transaction.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
      <div className="bg-white rounded-xl shadow-2xl max-w-lg w-full p-6 text-gray-800 max-h-[90vh] overflow-y-auto">
        <div className="flex justify-between items-center pb-3 border-b border-gray-100">
          <div>
            <h3 className="text-xl font-bold tracking-tight text-gray-900">Record Store Sale & Print</h3>
            <p className="text-xs text-gray-500">Customer: {customerName} (+{customerPhone})</p>
          </div>
          <button onClick={onClose} className="text-gray-400 hover:text-gray-600 text-2xl leading-none">&times;</button>
        </div>

        {errorMsg && (
          <div className="mt-3 p-3 bg-red-50 text-red-700 text-sm rounded border border-red-200">
            {errorMsg}
          </div>
        )}

        <form onSubmit={handleSubmit} className="mt-4 space-y-4">
          {outlets.length > 0 && (
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1">
                Store / Outlet
              </label>
              <select
                value={selectedOutlet}
                onChange={(e) => setSelectedOutlet(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 bg-white"
              >
                {outlets.map((o) => (
                  <option key={o.id} value={o.id}>{o.name}</option>
                ))}
              </select>
            </div>
          )}

          <div>
            <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1">
              Fragrance / Blend Name
            </label>
            <input
              type="text"
              required
              value={productName}
              onChange={(e) => setProductName(e.target.value)}
              placeholder="e.g. Royal Oud Blend (100ml)"
              className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1">
                Total Amount (₹)
              </label>
              <input
                type="number"
                required
                min="1"
                step="0.01"
                value={totalAmount}
                onChange={(e) => setTotalAmount(e.target.value === '' ? '' : parseFloat(e.target.value))}
                placeholder="2499.00"
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="block text-xs font-semibold uppercase tracking-wider text-gray-600 mb-1">
                Payment Method
              </label>
              <select
                value={paymentMethod}
                onChange={(e: any) => setPaymentMethod(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-amber-500 focus:outline-none bg-white"
              >
                <option value="UPI">UPI (GooglePay / PhonePe / Paytm)</option>
                <option value="CASH">Cash Counter</option>
                <option value="SPLIT">Split (Cash + UPI)</option>
                <option value="CREDIT_CARD">Credit Card POS</option>
                <option value="DEBIT_CARD">Debit Card POS</option>
              </select>
            </div>
          </div>

          {paymentMethod === 'SPLIT' && (
            <div className="p-3 bg-gray-50 rounded-lg border border-gray-200 grid grid-cols-2 gap-3">
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">Cash Part (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  value={cashSplit}
                  onChange={(e) => setCashSplit(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="1000"
                  className="w-full px-3 py-1.5 border border-gray-300 rounded focus:ring-1 focus:ring-amber-500 bg-white"
                />
              </div>
              <div>
                <label className="block text-xs font-medium text-gray-600 mb-1">UPI Part (₹)</label>
                <input
                  type="number"
                  step="0.01"
                  value={upiSplit}
                  onChange={(e) => setUpiSplit(e.target.value === '' ? '' : parseFloat(e.target.value))}
                  placeholder="1499"
                  className="w-full px-3 py-1.5 border border-gray-300 rounded focus:ring-1 focus:ring-amber-500 bg-white"
                />
              </div>
            </div>
          )}

          <div className="bg-amber-50 p-3 rounded-lg border border-amber-200 text-xs text-amber-900 space-y-1">
            <div className="flex justify-between">
              <span>Base Subtotal:</span>
              <span className="font-semibold">₹{subtotalAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between">
              <span>GST (18% inclusive):</span>
              <span className="font-semibold">₹{gstAmount.toFixed(2)}</span>
            </div>
            <div className="flex justify-between border-t border-amber-200 pt-1 font-bold text-sm text-gray-900">
              <span>Grand Total:</span>
              <span>₹{numAmount.toFixed(2)}</span>
            </div>
          </div>

          <div className="flex justify-end gap-2 pt-2">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-lg text-sm text-gray-700 hover:bg-gray-50"
            >
              Cancel
            </button>
            <button
              type="submit"
              disabled={loading}
              className="px-5 py-2 bg-amber-600 hover:bg-amber-700 text-white rounded-lg text-sm font-medium transition disabled:opacity-50"
            >
              {loading ? 'Recording...' : 'Record & Print Thermal Receipt'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
};
