// src/components/BulkProductUpload.tsx
import React, { useState } from 'react';

interface BulkProductUploadProps {
  onSuccess?: () => void;
  supabaseClient?: any;
}

// RFC 4180 Compliant CSV line parser handling commas, quotes, and escaped quotes
function parseCSVLine(text: string): string[] {
  const result: string[] = [];
  let cur = '';
  let inQuotes = false;
  
  for (let i = 0; i < text.length; i++) {
    const c = text[i];
    const next = text[i + 1];
    if (c === '"') {
      if (inQuotes && next === '"') {
        cur += '"';
        i++; // skip next quote
      } else {
        inQuotes = !inQuotes;
      }
    } else if (c === ',' && !inQuotes) {
      result.push(cur.trim());
      cur = '';
    } else {
      cur += c;
    }
  }
  result.push(cur.trim());
  return result;
}

export const BulkProductUpload: React.FC<BulkProductUploadProps> = ({ onSuccess, supabaseClient }) => {
  const [csvText, setCsvText] = useState('');
  const [parsing, setParsing] = useState(false);
  const [approving, setApproving] = useState(false);
  const [log, setLog] = useState<{ errors: string[]; added: number; skipped: number } | null>(null);
  const [approvalMsg, setApprovalMsg] = useState<string | null>(null);

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      setCsvText(event.target?.result as string || '');
    };
    reader.readAsText(file);
  };

  const processUpload = async () => {
    if (!csvText.trim()) return;
    setParsing(true);
    setLog(null);
    setApprovalMsg(null);

    const rawLines = csvText.split(/\r?\n/).filter((l) => l.trim().length > 0);
    if (rawLines.length <= 1) {
      setLog({ errors: ['CSV file contains no product rows.'], added: 0, skipped: 0 });
      setParsing(false);
      return;
    }

    const headers = parseCSVLine(rawLines[0]).map((h) => h.toLowerCase());
    const nameIdx = headers.indexOf('name');
    const categoryIdx = headers.indexOf('category');
    const familiesIdx = headers.indexOf('fragrance_families');
    const priceIdx = headers.indexOf('price');
    const notesIdx = headers.indexOf('notes');

    if (nameIdx === -1) {
      setLog({ errors: ["Missing mandatory header: 'name'"], added: 0, skipped: 0 });
      setParsing(false);
      return;
    }

    const productsToInsert: any[] = [];
    let skipped = 0;

    for (let i = 1; i < rawLines.length; i++) {
      const row = parseCSVLine(rawLines[i]);
      const name = row[nameIdx];
      if (!name) {
        skipped++;
        continue;
      }

      const category = categoryIdx !== -1 && row[categoryIdx] ? row[categoryIdx] : 'Fine Fragrance';
      const families = familiesIdx !== -1 && row[familiesIdx] 
        ? row[familiesIdx].split(';').map((f) => f.trim()).filter(Boolean)
        : [];
      const price = priceIdx !== -1 ? parseFloat(row[priceIdx]) || 0 : 0;
      const notes = notesIdx !== -1 ? row[notesIdx] : '';

      productsToInsert.push({
        name,
        category,
        fragrance_families: families,
        price,
        notes,
        status: 'DRAFT', // Loaded as DRAFT for owner verification
      });
    }

    try {
      if (!supabaseClient) throw new Error('Supabase client not initialized');

      const { error } = await supabaseClient
        .from('products')
        .upsert(productsToInsert, { onConflict: 'name' });

      if (error) throw error;

      setLog({
        errors: [],
        added: productsToInsert.length,
        skipped,
      });

      if (onSuccess) onSuccess();
    } catch (err: any) {
      setLog({
        errors: [err?.message || 'Error executing upload.'],
        added: 0,
        skipped: 0,
      });
    } finally {
      setParsing(false);
    }
  };

  const approveAllDrafts = async () => {
    if (!supabaseClient) return;
    setApproving(true);
    setApprovalMsg(null);
    try {
      const { data, error } = await supabaseClient
        .from('products')
        .update({ status: 'ACTIVE' })
        .eq('status', 'DRAFT')
        .select();

      if (error) throw error;
      setApprovalMsg(`Successfully activated ${data?.length || 0} pending DRAFT products for customer recommendations.`);
      if (onSuccess) onSuccess();
    } catch (err: any) {
      setApprovalMsg(`Error activating drafts: ${err.message}`);
    } finally {
      setApproving(false);
    }
  };

  return (
    <div className="bg-white rounded-xl shadow border border-gray-100 p-5 space-y-4">
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center pb-3 border-b border-gray-100 gap-2">
        <div>
          <h3 className="text-lg font-bold text-gray-900">Bulk Product Catalog Import</h3>
          <p className="text-xs text-gray-500">Upload CSV template to batch-insert fragrance catalog items safely.</p>
        </div>
        <button
          onClick={approveAllDrafts}
          disabled={approving}
          className="px-3 py-1.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-semibold rounded-lg transition disabled:opacity-50"
        >
          {approving ? 'Activating...' : 'Approve All DRAFT Products'}
        </button>
      </div>

      {approvalMsg && (
        <div className="p-3 bg-blue-50 border border-blue-200 text-blue-800 text-xs rounded-lg">
          {approvalMsg}
        </div>
      )}

      <div>
        <label className="block text-xs font-semibold uppercase tracking-wider text-gray-500 mb-2">
          Select Catalog CSV File
        </label>
        <input
          type="file"
          accept=".csv"
          onChange={handleFileUpload}
          className="block w-full text-sm text-gray-500 file:mr-4 file:py-2 file:px-4 file:rounded-lg file:border-0 file:text-xs file:font-semibold file:bg-amber-50 file:text-amber-700 hover:file:bg-amber-100 cursor-pointer"
        />
      </div>

      {log && (
        <div className={`p-3 rounded text-xs ${log.errors.length > 0 ? 'bg-red-50 text-red-700' : 'bg-green-50 text-green-800'}`}>
          {log.errors.length > 0 ? (
            <div>Errors: {log.errors.join(', ')}</div>
          ) : (
            <div>Successfully imported/updated {log.added} products as DRAFT ({log.skipped} skipped rows).</div>
          )}
        </div>
      )}

      <div className="flex justify-end">
        <button
          onClick={processUpload}
          disabled={parsing || !csvText}
          className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white text-xs font-bold rounded-lg transition disabled:opacity-50"
        >
          {parsing ? 'Parsing & Importing...' : 'Execute Bulk Upload'}
        </button>
      </div>
    </div>
  );
};
