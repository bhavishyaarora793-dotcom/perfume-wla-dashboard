// src/lib/whatsappCadence.ts

export type FollowUpStage = 'DAY_3' | 'DAY_14' | 'DAY_60' | 'DAY_90' | 'DAY_120';

export interface FollowUpItem {
  id: string;
  customerName: string;
  phone: string;
  fragranceName: string;
  purchaseDate: string; // ISO string
  stage: FollowUpStage;
  invoiceNumber?: string;
}

export function sanitizeIndianPhone(phone: string): string {
  const cleaned = phone.replace(/\D/g, '');
  if (cleaned.length === 10) {
    return `91${cleaned}`;
  }
  if (cleaned.length === 12 && cleaned.startsWith('91')) {
    return cleaned;
  }
  return cleaned;
}

export function generateFollowUpMessage(item: FollowUpItem): string {
  const { customerName, fragranceName, invoiceNumber, stage } = item;
  
  switch (stage) {
    case 'DAY_3':
      return `Hi ${customerName}! ✨ Hope you are enjoying your signature bottle of *${fragranceName}* from PerfumeWala. How is the scent projecting throughout the day? Feel free to reach out if you'd like tips on pulse point application!`;
    case 'DAY_14':
      return `Hello ${customerName}! 🌿 Are you getting compliments on your *${fragranceName}*? If you'd like to explore evening layering combinations with woody or ambery notes, visit our fragrance bar anytime!`;
    case 'DAY_60':
      return `Hi ${customerName}! 🧴 Your bottle of *${fragranceName}* might be reaching the halfway mark. Stop by PerfumeWala this week to re-order or test our freshly curated seasonal accords!`;
    case 'DAY_90':
      return `Greetings ${customerName}! It has been 90 days since your perfume creation. As a valued customer${invoiceNumber ? ` (Inv: ${invoiceNumber})` : ''}, we've unlocked a complimentary fragrance refill privilege on your next visit!`;
    case 'DAY_120':
      return `Hello ${customerName}, we miss you at the PerfumeWala bar! ✨ Drop by for a complimentary skin-chemistry re-evaluation and discover what's new in our artisan collection.`;
    default:
      return `Hi ${customerName}, checking in from PerfumeWala! Hope you're loving your custom perfume experience.`;
  }
}

export function buildWhatsAppDirectLink(item: FollowUpItem): string {
  const phone = sanitizeIndianPhone(item.phone);
  const msg = generateFollowUpMessage(item);
  return `https://wa.me/${phone}?text=${encodeURIComponent(msg)}`;
}
