-- PerfumeWala Complete Production Migration
-- Applied via Supabase SQL Editor

-- 1. Create Enums
DO $$ BEGIN
    CREATE TYPE payment_mode_enum AS ENUM ('CASH', 'UPI', 'CREDIT_CARD', 'DEBIT_CARD', 'SPLIT');
EXCEPTION
    WHEN duplicate_object THEN null;
END $$;

-- 2. Ensure Outlets Table exists (for franchise / multi-outlet isolation)
CREATE TABLE IF NOT EXISTS outlets (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(128) NOT NULL,
    code VARCHAR(32) UNIQUE NOT NULL,
    city VARCHAR(64) DEFAULT 'Delhi',
    address TEXT,
    gstin VARCHAR(32),
    phone VARCHAR(32),
    created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

-- Seed default pilot outlet if none exists
INSERT INTO outlets (name, code, city, address)
VALUES ('PerfumeWala Flagship Experience Center', 'PW-DEL-01', 'Delhi', 'Flagship Perfume Bar, Delhi')
ON CONFLICT (code) DO NOTHING;

-- 3. Purchases Table Enhancements
ALTER TABLE purchases 
ADD COLUMN IF NOT EXISTS outlet_id UUID REFERENCES outlets(id),
ADD COLUMN IF NOT EXISTS invoice_number VARCHAR(64) UNIQUE,
ADD COLUMN IF NOT EXISTS payment_method payment_mode_enum DEFAULT 'UPI',
ADD COLUMN IF NOT EXISTS payment_split_cash NUMERIC(10, 2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS payment_split_upi NUMERIC(10, 2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS payment_status VARCHAR(32) DEFAULT 'PAID',
ADD COLUMN IF NOT EXISTS subtotal_amount NUMERIC(10, 2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS gst_rate_pct NUMERIC(4, 2) DEFAULT 18.00,
ADD COLUMN IF NOT EXISTS gst_amount NUMERIC(10, 2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS total_amount NUMERIC(10, 2) DEFAULT 0.00,
ADD COLUMN IF NOT EXISTS batch_lot VARCHAR(64),
ADD COLUMN IF NOT EXISTS maceration_date DATE DEFAULT CURRENT_DATE;

-- Default existing purchases to the flagship outlet
UPDATE purchases 
SET outlet_id = (SELECT id FROM outlets WHERE code = 'PW-DEL-01' LIMIT 1)
WHERE outlet_id IS NULL;

-- 4. Automatic Invoice Sequence & GST Calculation Trigger
CREATE SEQUENCE IF NOT EXISTS invoice_seq START 1001;

CREATE OR REPLACE FUNCTION generate_perfumewala_invoice()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.invoice_number IS NULL THEN
        NEW.invoice_number := 'PW-' || TO_CHAR(NOW(), 'YYYYMM') || '-' || NEXTVAL('invoice_seq');
    END IF;
    -- Standard India GST calculation (18% inclusive logic)
    IF NEW.total_amount > 0 AND (NEW.gst_amount IS NULL OR NEW.gst_amount = 0) THEN
        NEW.gst_amount := ROUND((NEW.total_amount * NEW.gst_rate_pct) / (100 + NEW.gst_rate_pct), 2);
        NEW.subtotal_amount := NEW.total_amount - NEW.gst_amount;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

DROP TRIGGER IF EXISTS trg_generate_invoice ON purchases;
CREATE TRIGGER trg_generate_invoice
BEFORE INSERT ON purchases
FOR EACH ROW
EXECUTE FUNCTION generate_perfumewala_invoice();

-- 5. Products Table Status and Mass Approval
ALTER TABLE products 
ADD COLUMN IF NOT EXISTS status VARCHAR(32) DEFAULT 'DRAFT',
ADD COLUMN IF NOT EXISTS notes TEXT,
ADD COLUMN IF NOT EXISTS fragrance_families TEXT[];

-- 6. Operational & Cadence App Settings
CREATE TABLE IF NOT EXISTS app_settings (
    key VARCHAR(64) PRIMARY KEY,
    value TEXT NOT NULL,
    description TEXT,
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

INSERT INTO app_settings (key, value, description)
VALUES 
    ('followup_post_purchase_days', '3', 'First impressions & wear check'),
    ('followup_mid_check_days', '14', 'Layering advice and feedback'),
    ('followup_replenish_days', '60', 'Half-bottle refill prompt'),
    ('followup_churn_risk_days', '120', 'Win-back reactivation trigger'),
    ('operational_start_date', TO_CHAR(CURRENT_DATE + ((7 - EXTRACT(DOW FROM CURRENT_DATE)::integer) % 7 + 1), 'YYYY-MM-DD'), 'Next Monday Sprint Start')
ON CONFLICT (key) DO UPDATE 
SET value = EXCLUDED.value,
    updated_at = NOW();

-- 7. Row Level Security (RLS) Configuration
ALTER TABLE purchases ENABLE ROW LEVEL SECURITY;
ALTER TABLE outlets ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_settings ENABLE ROW LEVEL SECURITY;
ALTER TABLE products ENABLE ROW LEVEL SECURITY;

-- Purchases Policies
DROP POLICY IF EXISTS "Authenticated staff can view and record purchases" ON purchases;
CREATE POLICY "Authenticated staff can view and record purchases"
ON purchases FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

-- Outlets Policies
DROP POLICY IF EXISTS "Public or staff can read outlets" ON outlets;
CREATE POLICY "Public or staff can read outlets"
ON outlets FOR SELECT
TO authenticated, anon
USING (true);

-- App Settings Policies
DROP POLICY IF EXISTS "Staff can read app settings" ON app_settings;
CREATE POLICY "Staff can read app settings"
ON app_settings FOR SELECT
TO authenticated, anon
USING (true);

DROP POLICY IF EXISTS "Staff can update app settings" ON app_settings;
CREATE POLICY "Staff can update app settings"
ON app_settings FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

-- Products Policies
DROP POLICY IF EXISTS "Staff can manage products" ON products;
CREATE POLICY "Staff can manage products"
ON products FOR ALL
TO authenticated
USING (true)
WITH CHECK (true);

DROP POLICY IF EXISTS "Public can view active products" ON products;
CREATE POLICY "Public can view active products"
ON products FOR SELECT
TO anon
USING (status = 'ACTIVE');
